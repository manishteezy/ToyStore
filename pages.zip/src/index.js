import React from 'react';
import ReactDOM from 'react-dom';
//import $ from 'jquery';
import './index.css';
import App from './App';
//import Header1 from './Header1';
//import Footer1 from './Footer1';
import 'bootstrap';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import * as serviceWorker from './serviceWorker';
//import Carousel from './Carousel';



ReactDOM.render(<App />, document.getElementById('root'));


// ReactDOM.render(<Header1 />,
//     <Carousel />,
//     <Footer1 />,
//     document.getElementById('root'));

// ReactDOM.render(
//             , document.getElementById('carousel'));

// ReactDOM.render(,
//          document.getElementById('footer'));



serviceWorker.unregister();
