import React from 'react';
import './About.css';
import cc1 from './Images/cc1.jpg';
function About() {
    return(
        <div>
      <nav class="navbar navbar-expand py-3  mb-0 bg-pink">
         <div class="text-center w-100">
            <h6><a class="text-white" href="index.html">Home  </a> / / About Us</h6>
         </div>
      </nav>


      <div class="container-fluid py-4">
      	<div class="container py-5 px-3 mx-auto">
      		<h1 class="text-center font-weight-bold mb-5"> About Us</h1>
      		<h2 class="text-center mb-4 font-pink"> WELCOME TO OUR STORE</h2>
      		<p class="mb-3"> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere</p>
      		<img src={cc1} alt="teddy" title="teddy" />
      		<div class="container mt-4  pt-5">
      			<h3 class="font-pink text-center">A FASTER AND BETTER BEST TO SHOP</h3>

      			<div class="row">
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="   fa fa-truck text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Shipping</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="   fa fa-volume-control-phone text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Support</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="   fa fa-exchange text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Return</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			</div>
      		</div>
      	</div>
      </div>
  </div>
    )
}
export default About