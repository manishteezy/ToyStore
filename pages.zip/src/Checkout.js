import React from 'react';
//import './Checkout.css';
import a1 from './Images/a1.jpg';
import a2 from './Images/a2.jpg';
import a3 from './Images/a3.jpg';
import a4 from './Images/a4.jpg';

function Checkout() {
    return(
        <div>
      <nav class="navbar navbar-expand py-3  mb-0 bg-pink">
         <div class="text-center w-100">
            <h6><a class="text-white" href="index.html">Home  </a> / / Checkout</h6>
         </div>
      </nav>
      <div class="container-fluid py-4">
         <div class="container py-5">
            <span>
               <h3 class="font-weight-bold">Checkout </h3>
            </span>
            <h4 class="my-3">
               Your shopping cart contains: 3 Products
            </h4>
            <table class="table border">
               <thead class="thead-dark">
                  <tr class="text-center">
                     <th class="border"> SL No.</th>
                     <th class="border"> Product</th>
                     <th class="border"> Quantity</th>
                     <th class="border"> Product Name</th>
                     <th class="border"> Price</th>
                     <th class="border"> Remove</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <td class="text-center align-middle border"> 1</td>
                     <td class="text-center align-middle border"> <img class="w-25" src={a1} alt="teddy"/></td>
                     <td class="text-center align-middle border">
                        <div class="quantiy-select">
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">-</a>
                           </div>
                           <span class="value mr-1 py-2 text-center"> 1 
                           </span>
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">+</a>
                           </div>
                        </div>
                     </td>
                     <td class="text-center align-middle border"> Bella Toes</td>
                     <td class="text-center align-middle border"> $1000</td>
                     <td class="text-center align-middle border"> <a class="text-dark font-weight-bold" href="index.html">&times</a> </td>
                  </tr>
                  <tr>
                     <td class="text-center align-middle border"> 2</td>
                     <td class="text-center align-middle border"> <img class="w-25" src={a2} alt="teddy"/></td>
                     <td class="text-center align-middle border">
                        <div class="quantiy-select">
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">-</a>
                           </div>
                           <span class="value mr-1 py-2 text-center"> 1 
                           </span>
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">+</a>
                           </div>
                        </div>
                     </td>
                     <td class="text-center align-middle border"> Bella Toes</td>
                     <td class="text-center align-middle border"> $1000</td>
                     <td class="text-center align-middle border"> <a class="text-dark font-weight-bold" href="index.html">&times</a> </td>
                  </tr>
                  <tr>
                     <td class="text-center align-middle border"> 3</td>
                     <td class="text-center align-middle border"> <img class="w-25" src={a3} alt="teddy"/></td>
                     <td class="text-center align-middle border">
                        <div class="quantiy-select">
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">-</a>
                           </div>
                           <span class="value mr-1 py-2 text-center"> 1 
                           </span>
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">+</a>
                           </div>
                        </div>
                     </td>
                     <td class="text-center align-middle border"> Bella Toes</td>
                     <td class="text-center align-middle border"> $1000</td>
                     <td class="text-center align-middle border"> <a class="text-dark font-weight-bold" href="index.html">&times</a> </td>
                  </tr>
                  <tr>
                     <td class="text-center align-middle border"> 4</td>
                     <td class="text-center align-middle border"> <img class="w-25" src={a4} alt="teddy" /></td>
                     <td class="text-center align-middle border">
                        <div class="quantiy-select">
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">-</a>
                           </div>
                           <span class="value mr-1 py-2 text-center"> 1 
                           </span>
                           <div class="mr-1 text-center font-weight-bold border d-inline-block w-25">
                              <a href="index.html">+</a>
                           </div>
                        </div>
                     </td>
                     <td class="text-center align-middle border"> Bella Toes</td>
                     <td class="text-center align-middle border"> $1000</td>
                     <td class="text-center align-middle border"> <a class="text-dark font-weight-bold" href="index.html">&times</a> </td>
                  </tr>
               </tbody>
            </table>
            <div class="row mt-4">
               <div class="col-4">
                  <h5 class=" p-2 mb-4 text-center text-white bg-warning"> CONTINUE TO BASKET</h5>
                  <ul>
                     <li class="mb-3 text-grey" >
                        <span class="">	Product1 - </span> <span class="float-right">$500</span>
                     </li>
                     <li class="mb-3 text-grey" >
                        <span class="">	Product2 - </span> <span class="float-right">$500</span>
                     </li>
                     <li class="mb-3 text-grey" >
                        <span class="">	Product3 - </span> <span class="float-right">$500</span>
                     </li>
                     <li class="mb-3 text-grey" >
                        <span class="">	Product4 - </span> <span class="float-right">$500</span>
                     </li>
                  </ul>
               </div>
               <div class="col-8">
                  <h4 class="my-3"> Add a new Details</h4>
                  <label class="mb-2 font-weight-bold">Full name: </label>
                  <input class="form-control p-3 mb-4" type="text" name="name" placeholder="Full Name"/>
                  <label class="mb-2 font-weight-bold">Mobile Number: </label>
                  <input class="form-control p-3 mb-4" type="text" name="name" placeholder="Mobile Number"/>
                  <label class="mb-2 font-weight-bold">Landmark: </label>
                  <input class="form-control p-3 mb-4" type="text" name="name" placeholder="Landmark"/>
                  <label class="mb-2 font-weight-bold">Town/city: </label>
                  <input class="form-control p-3 mb-4" type="text" name="name" placeholder="Town/city"/>
                  <label class="mb-2 font-weight-bold">Address type: </label>
                  <select class="form-control p-3 mb-4">
                     <option>Office</option>
                     <option>Home</option>
                     <option>Commercial</option>
                  </select>
                  <button class="btn d-block btn-shop-now text-white">Delivery to this Address </button>
                  <button class="btn my-5 float-right btn-shop-now text-white"> Make a Payment</button>
               </div>
            </div>
         </div>
      </div>
   </div>
    )
}
export default Checkout