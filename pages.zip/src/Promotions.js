import React from 'react';
//import './Carousel.css';
import a1 from './Images/a1.jpg';
import a2 from './Images/a2.jpg';
import a3 from './Images/a3.jpg';
import a4 from './Images/a4.jpg';
import a5 from './Images/a5.jpg';
import a6 from './Images/a6.jpg';


function Promotions() {
    return (
<div class="container-fluid py-4 px-0">
         <div class=" container container-promotions position-relative bg-light py-5 px-3 text-center">
            <h3 class="font-weight-bold"> Best Products </h3>
            <div class="row">
               <div class="col-4 ">
                  <img class="border" src={a1} alt="promotion"/>
               </div>
               <div class="col-4">
                  <img class="border" src={a2} alt="promotion" />
               </div>
               <div class="col-4">
                  <img class="border" src={a3} alt="promotion"/>
               </div>
            </div>
            <div class="row">
               <div class="col-4">
                  <h4 class="pt-3 font-weight-bold mb-3"> Baby toys </h4>
               </div>
               <div class="col-4">
                  <h4 class="pt-3 font-weight-bold mb-3"> Lite-Brite </h4>
               </div>
               <div class="col-4">
                  <h4 class="pt-3 font-weight-bold mb-3"> Key Toys </h4>
               </div>
            </div>
            <div class="row">
               <div class="col-4 ">
                  <img class="border" src={a4} alt="promotion"/>
               </div>
               <div class="col-4">
                  <img class="border" src={a5} alt="promotion"/>
               </div>
               <div class="col-4">
                  <img class="border" src={a6} alt="promotion"/>
               </div>
            </div>
            <div class="promotion-overlay text-center text-white position-absolute">
               <h3> GET UP TO <span> 70% OFF </span> ON SELECTED <br/> TOYS
               </h3>
            </div>
         </div>
      </div>
    );
}

export default Promotions