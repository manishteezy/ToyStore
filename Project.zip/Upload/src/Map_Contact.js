import React from 'react';
//import 'Map_Contact.css';

function MapContact(){
    return(
        <div class="container-fluid py-0 px-0">
         <div class="row no-gutters">
            <div class="col-6 px-0">
               <iframe class="h-100 w-100 map" title="google map" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3150859.767904157!2d-96.62081048651531!3d39.536794757966845!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1408111832978"> </iframe>
            </div>
            <div class="col-6 py-4 bg-warning">
               <div class="text-center">
                  <h2 class="mb-0"> <span class="fa fa-map"></span></h2>
                  <p class="mb-0">25478 Road St.121</p>
                  <p class="mb-0">USA New Hill</p>
                  <br/>
               </div>
               <div class="text-center">
                  <h2 class="mb-0"> <span class="fa fa-volume-control-phone"></span> </h2>
                  <p class="mb-0">+(000)123 4565 </p>
                  <p class="mb-0"> +(010)123 4565</p>
                  <br/>
               </div>
               <div class="text-center">
                  <h2 class="mb-0">  <span class="fa fa-envelope"></span> </h2>
                  <p class="mb-0"> info@example1.com</p>
                  <p class="mb-0"> info@example1.com</p>
               </div>
            </div>
         </div>
      </div>
    );
}
export default MapContact