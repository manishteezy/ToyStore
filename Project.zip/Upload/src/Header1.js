import React from 'react';
import './Header1.css';
import 'bootstrap';
//import Carousel from './Carousel';


function Header() {
    return (
      <div class="header">
          <nav class="navbar navbar-expand bg-white-navbar py-2 px-5 mb-0">
            <ul class="navbar-nav">
               <li class="my-auto mr-3">
                  <span class="mr-1 fa fa-volume-control-phone p-0"></span>
                  <span class="ml-1 "> Ph: +(000)123 4565 32</span>
               </li>
               <li class="nav-item">
                  <span class="fa fa-envelope mr-1 p-0"></span>
                  <span><a class="nav-link d-inline-block ml-1" href="index.html"> info@example1.com </a> </span>
               </li>
            </ul>
         </nav>
         <nav class="navbar navbar-expand mb-0 bg-dark text-white py-3 px-5 ">
            <ul class="navbar-nav w-100">
               <div class="row w-100">
                  <li class="nav-item col-lg-3">
                     <div>
                        <h1> <a class="text-white" href="index.html">Toys-Shop </a></h1>
                     </div>
                  </li>
                  <li class="px-3 nav-item col-lg-5 w-100 my-auto" >
                     <input class="w-100" type="text" name="search" placeholder="  Search"/>
                     <button class="text-white"> Search </button>
                  </li>
                  <li class="nav-item my-auto ml-5">
                     <ul class="navbar-nav w-100">
                        <li class="nav-item text-center">
                           <div class="border icon text-center">
                              <a class="d-inline-block" href="index.html"><span class="fa fa-envelope w-20 h-20"></span></a>
                           </div>
                        </li>
                        <li class="nav-item text-center ml-4">
                              <div class="border icon text-center">
                              <a class="d-inline-block" href="index.html"><span class="fa fa-user w-20 h-20"></span></a>
                           </div>
                        </li>
                        <li class="nav-item text-center ml-4">
                           <div class="border icon text-center">
                              <span class="fa fa-cart-arrow-down w-20 h-20"></span>
                           </div>
                        </li>
                     </ul>
                  </li>
               </div>
            </ul>
         </nav>
         <nav class="navbar navbar-expand py-3 bg-white-navbar mb-0">
            <ul class="navbar-nav w-100 justify-content-center">
               <li class="nav-item">
                  <a class="nav-link active py2 px-5" href="index.html" > HOME </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link py2 px-5" href="about.html" > ABOUT </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link py2 px-5" href="service.html" > SERVICE </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link py2 px-5" href="index.html" > SHOP NOW </a>
               </li>
               <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle py2 px-5" href="index.html" data-toggle="dropdown">
                  Pages
                  </a>
                  <div class="dropdown-menu py2 px-5">
                     <a class="nav-link " href="www.ggogle.com">404 Page</a>
                     <a class="nav-link " href="www.ggogle.com">Typography</a>
                  </div>
               </li>
               <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle py2 px-5" href="index.html" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Product
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <a class="nav-link" href="product.html">Kids Toys</a>
                     <a class="nav-link " href="product.html">Dolls</a>
                     <a class="nav-link " href="product.html">Key Toys</a>
                     <a class="nav-link " href="product.html">Boys Toys</a>
                  </div>
               </li>
               <li class="nav-item">
                  <a class="nav-link py2 px-4" href="contact.html" > CONTACT </a>
               </li>
            </ul>
         </nav>
      </div>
      
    );
  }
  
  export default Header;