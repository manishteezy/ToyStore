import React from 'react';
//import './Carousel.css';
import './Scroll.css';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import a1 from './Images/a1.jpg';
 import a2 from './Images/a2.jpg';
 import a3 from './Images/a3.jpg';
 import a4 from './Images/a4.jpg';
 import a5 from './Images/a5.jpg';
  import a6 from './Images/a6.jpg';

function Scroll() {
    return (
<div class="container-fluid py-4 px-0 bg-success">
         <div class="container py-5 px-3 text-center">
            <h1 class="font-weight-bold text-white mb-5"> New Arrivals </h1>
            <div class="row no-gutters">


            <OwlCarousel className="owl-theme" margin={10}
             items={4}
              navText dots={false}>
                
            <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a1} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a2} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a3} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a4} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a5} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a6} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
               <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={a1} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
            </OwlCarousel>            
         </div>
               
    </div>
      </div>
      );
      }
    
      export default Scroll

