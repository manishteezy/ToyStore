class First extends React.Component {
        constructor(props) {
          super(props);
          this.state = {
            data: [{name: 'bob', price:123 } ],
          };
        }
        
        render() {
          return (
            <ul>
              { this.state.data.map(d =>  <li key={d.name} key={d.price } > {d.name} {d.price} </li>    )}
            </ul>
          );
        }
      }
      
      ReactDOM.render(
        <First />,
        
      );
        