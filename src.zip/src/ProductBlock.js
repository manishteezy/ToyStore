import React from 'react';
// import './Producimg.css'
function ProductBlock(props)
{
    return(
        <React.Fragment>
            <div class="col">
                <div class="card p-3" >
                <img src={props.image} class="card-img-top img-thumbnail " alt="..." />
                <hr/>
                <div class="card-body row">
                <div class="col-md-7">
                <h5 class="cardtit" >{props.name}</h5>
                <p>$575.00</p>
                <span><i class="fa fa-star"></i></span>
                <span><i class="fa fa-star"></i></span>
                <span><i class="fa fa-star"></i></span>
                <span><i class="fa fa-star"></i></span>
                </div>
                <div class="col-md-5 mt-5">
                <i class="fa fa-cart-plus size-50" ></i>
               </div>
             </div>
          </div>
          </div>
       
        </React.Fragment>
    
    )
}
 export default ProductBlock