import React from 'react';
import './CoustomerReviewBlock.css';


function CoustomerReviewBlock(props) {
    return (
<div class="col-5 mx-3 bg-white-navbar" >
                  <div class="row p-5">
                     <div class="col-4">
                        <figure>
                           <img class="img-fluid rounded-circle" src={props.ProfileImage} alt="teddy" />
                        </figure>
                     </div>
                     <div class="col-8">
                        <h4 class="pt-4 font-weight-bold">
                           Milky Deo
                        </h4>
                        <p class="mt-2 text-success"> Duis posuere </p>
                     </div>
                     <div class="mt-3">
                        <img src={props.Image} alt="teddy" /> 
                        <p> <span class="fa fa-quote-left"></span> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere <span class="fa fa-quote-right"></span></p>
                     </div>
                  </div>
               </div>
    );
}
export default CoustomerReviewBlock