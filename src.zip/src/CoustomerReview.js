import React from 'react';
import './CoustomerReview.css';
import CoustomerReviewBlock from './CoustomerReviewBlock';
import t1 from './Images/t1.jpg';
import tt1 from './Images/tt1.jpg';


function CoustomerReview() {
    return (
        <div class="container-fluid px-0 py-4 customoers-review">
         <div class="container">
            <h1 class="text-center mb-5 text-white"> Customers Review </h1>
            <div class="row justify-content-center">
               <CoustomerReviewBlock ProfileImage={t1} Image={tt1} />
               <CoustomerReviewBlock ProfileImage={t1} Image={tt1} />
            </div>
         </div>
      </div>
    );
}
export default CoustomerReview