import React from 'react';
import './Footer1.css';
import MapContact from './Map_Contact';
import GetInTouch from './GetInTouch';
import Copyrights from './Copyrights'

function Footer1() {
  return(
  <div>
      <MapContact/>
      <GetInTouch/>
      <Copyrights/>
      </div>
  );
  }

  export default Footer1;