import React from 'react';
import './Product.css';
import a1 from './Images/a1.jpg';
 import a2 from './Images/a2.jpg';
 import a3 from './Images/a3.jpg';
 import a4 from './Images/a4.jpg';
 import a5 from './Images/a5.jpg';
  import a6 from './Images/a6.jpg';

function Product(props){
    return(
        <div class="marqee-image item">
                  <img class="border img-fluid mx-auto" src={props.image} alt="promotion"/> <br/>
                  <div>
                     <p class="mb-3 font-weight-bold"> Soft toys</p>
                     <br/> 
                  </div>
                   <button class="btn"> SHOP NOW</button> 
               </div>
    );
} 
export default Product