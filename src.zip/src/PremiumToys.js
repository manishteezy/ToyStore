import React from 'react';
import pp1 from './Images/pp1.png';
import './PremiumToys.css'

function PremiumToys(){
    return(
<div class="container-fluid bg-success py-4 pr-0 pl-0">
         <div class="container py-5">
            <h3 class="text-white text-center mb-5">Premium Toys</h3>
            <div class="row">
               <div class="col-6">
                  <img class="teddy-left" src={pp1} alt="teddy"/>
               </div>
               <div class="col-6">
                  <div class="toy-info pt-4 pd-4 pr-5 pl-5">
                     <p>
                        velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere
                     </p>
                     <button class="btn text-white btn-shop-now mt-4"> SHOP NOW</button>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-6">
                  <div class="toy-info pt-4 pd-4 pr-5 pl-5">
                     <p>
                        velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere
                     </p>
                     <button class="btn text-white btn-shop-now mt-4 text-left"> SHOP NOW</button>
                  </div>
               </div>
               <div class="col-6">
                  <img class="teddy-left" src={pp1} alt="teddy"/>
               </div>
            </div>
         </div>
      </div>
    );
}
export default PremiumToys