import React from'react';
import './GetInTouch.css';

function GetInTouch(){
    return(
        <div class="container-fluid py-4 bg-success">
         <div class="container py-5 px-3">
            <h1 class=" text-center mb-5 text-white display-4">Get In Touch Us</h1>




            <div class="col-md-12 d-flex justify-content-center p-2">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" href="#">
            <span class="fa fa-facebook-f border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <span class="fa fa-envelope border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <span class="fa fa-rss border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">
            <span class="fa fa-vk border border-danger p-3"></span>
          </a>
        </li>
      </ul>
    </div>
    
            {/* <div class="icons text-center">
               <a href="index.html">

                  <h2 class="d-inline-block mr-3"><span class="fa fa-facebook-f"></span></h2>
               </a>
               <a href="index.html">
                  <h2 class="d-inline-block mr-3"><span class="fa fa-envelope"></span></h2>
               </a>
               <a href="index.html">
                  <h2 class="d-inline-block mr-3"><span class="fa fa-rss"></span></h2>
               </a>
               <a href="index.html">
                  <h2 class="d-inline-block mr-3"><span class="fa fa-vk"></span></h2>
               </a>
            </div> */}
            <p class="my-3 text-center">
               velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis <br/> posuere
            </p>
            <div class="text-center">
               <input class="form-control col-6 mx-auto" type="email" name="email"
                  placeholder=" Email"/>
               <button class="btn text-white btn-shop-now mt-4 text-center"> SUBSCRIBE</button>
            </div>
         </div>
      </div>
    );
}
export default GetInTouch