import React from 'react';
import './Service.css';

function Service(props) {
return(
                    <div class="col-4 text-center d-inline-block">      
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="fa fa-{props.Icon} text-warning align-middle"></span></h1>
                      fa fa-{props.Icon} text-warning align-middle
      			</div>
      			<h4 class="text-center font-weight-bold"> {props.Service}</h4>
      				<p class="mt-4">{props.Description} </p>
      			</div>
    );

}
export default Service