import React from 'react';
//import './Carousel.css';
import './Scroll.css';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Product from './Product';
import a1 from './Images/a1.jpg';
 import a2 from './Images/a2.jpg';
 import a3 from './Images/a3.jpg';
 import a4 from './Images/a4.jpg';
 import a5 from './Images/a5.jpg';
  import a6 from './Images/a6.jpg';

function Scroll() {
    return (
<div class="container-fluid py-4 px-0 bg-success">
         <div class="container py-5 px-3 text-center">
            <h1 class="font-weight-bold text-white mb-5"> New Arrivals </h1>
            <div class="row no-gutters">


            <OwlCarousel className="owl-theme" margin={10}
             items={4}
              navText dots={false}>
                <Product image={a1} />
                <Product image={a2} />
                <Product image={a3} />
                <Product image={a4} />
                <Product image={a5} />
                <Product image={a6} />
            </OwlCarousel>            
         </div>
               
    </div>
      </div>
      );
      }
    
      export default Scroll

