import React from 'react';
import './PageHeading.css';

function PageHeading(props) {
    return(
<nav class="navbar navbar-expand py-3  mb-0 bg-pink">
         <div class="text-center w-100">
            <h6 class="text-white"><a class="text-white" href="index.html">Home </a> / / {props.Page} </h6>
         </div>
      </nav>
    );
}
export default PageHeading