import React from 'react';
import './Error.css';

function Error(){
    return(
<div>
    <section class="text-center ">
	    <p class="text-success size-100" >404</p>
	    <p>sorry but the page that you requested doesn't exist</p>
     </section>
      <div class="col-md-12 d-flex justify-content-center p-3">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" href="#">
            <span class="fa fa-facebook-f border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <span class="fa fa-envelope border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
            <span class="fa fa-rss border border-danger p-3"></span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">
            <span class="fa fa-vk border border-danger p-3"></span>
          </a>
        </li>
      </ul>
    </div>
  </div>
    );
}
export default Error