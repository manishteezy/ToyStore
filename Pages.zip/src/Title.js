import React from 'react';
import './Title.css';

function Title(props) {
return (
<div class="mt-5 text-center pt-5 container">
  <h1 class="font-weight-bold">{props.Title}</h1>
  <hr/>
</div>
    );
}
export default Title