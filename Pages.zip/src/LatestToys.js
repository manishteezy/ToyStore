import React from 'react';
import cc1 from './Images/cc1.jpg';
import cc2 from './Images/cc2.jpg';
import tt1 from './Images/tt1.jpg';
import './LatestToys.css'

function LatestToys() {
    return (
        <div class="container-fluid py-4 px-0">
         <div class="container py-5 px-3">
            <h1 class=" text-center mb-5 font-weight-bold">
               Latest toys
            </h1>
            <img src={cc1} alt=" teddy"/>
            <p class="mt-3"> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis <br/>posuere
            </p>
            <button class="btn text-white btn-shop-now mb-4"> SHOP NOW</button>
            <div class="row">
               <div class="col-6">
                  <img src={cc2} alt="teddy"/>
                  <p class="mt-4"> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere</p>
                  <button class="btn text-white btn-shop-now mb-4"> SHOP NOW</button>
               </div>
               <div class="col-6">
                  <div class="col-12">
                     <img class=" teddy-side" src={tt1} alt="teddy"/>
                     <p class="mt-4"> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere</p>
                     <button class="btn text-white btn-shop-now mb-4"> SHOP NOW</button>
                  </div>
                  <div class="col-12">
                     <img class=" teddy-side" src={cc1} alt="teddy"/>
                     <p class="mt-4"> velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt velit sagittis vehicula. Duis posuere velit sagittis vehicula. Duis posuere</p>
                     <button class="btn text-white btn-shop-now mb-4"> SHOP NOW</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
      );
      }
      export default LatestToys