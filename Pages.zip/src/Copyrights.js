import React from 'react';
import './Copyrights.css';

function Copyrights() {
    return(
        
<footer class="container-fluid bg-dark py-4 text-center text-white">
         © 2018 Toys-Shop. All Rights Reserved | Design by <a href="index.html">Manish Teezy</a>
      </footer> 
    );
}
export default Copyrights