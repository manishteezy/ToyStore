
import React from 'react';
import './App.css';
//import Header from './Header';
//import Carousel from './Carousel';
//import { directive } from '@babel/types';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Homepage from './Pages/Homepage';
import Servicepage from './Pages/Servicepage';
import Checkoutpage from './Pages/Checkoutpage';
import Aboutpage from './Pages/Aboutpage';
import Productpage from './Pages/Productpage';
import {BrowserRouter,Route,Switch} from 'react-router-dom';

function App() {
       return (




        <Productpage />
    //      <BrowserRouter>
    // <div>
    //   <Switch>
    //  <Route path="/about" component={Aboutpage}/>
    //    <Route path="/checkout" component={Checkoutpage}/>
    //    <Route path="/" exact component={Homepage}/>
    //    <Route path="/service" component={Servicepage}/>
    //    <Route path="/product" component={Productpage}/>
    //    {/* <Route path="/contact" component={Contactpage}/> */}
    //    </Switch>
    // </div>
    // </BrowserRouter>
  );
}

export default App;

