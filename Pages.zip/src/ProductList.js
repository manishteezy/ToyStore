import React from 'react';
import ProductBlock from './ProductBlock';
 








function ProductList() {
    return(
        <div class="row">
        <ProductBlock />
        <ProductBlock />
        <ProductBlock />
        <ProductBlock />

        </div>
    );
}

export default ProductList