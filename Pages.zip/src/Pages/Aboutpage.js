import React from 'react';
//import ReactDOM from 'react-dom';
import Header from '../Header1';
import Footer1 from '../Footer1';
import 'bootstrap';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';
//import * as serviceWorker from './serviceWorker';
import Carousel from '../Carousel';
import Promotions from '../Promotions';
import Scroll from '../Scroll';
import CoustomerReview from '../CoustomerReview';
import LatestToys from '../LatestToys';
import PremiumToys from '../PremiumToys';
import AboutToys from '../AboutToys';
import Banner from '../Banner';
import Checkout from '../Checkout';
import About from '../About';
import PageHeading from '../PageHeading'



function Aboutpage() {
    return (
      <div>
        <Header/>
        <Banner/>
        <PageHeading Page={"About"} />
        <About/>
        <Footer1/>
      </div>
    );
  }
  
  export default Aboutpage;
  