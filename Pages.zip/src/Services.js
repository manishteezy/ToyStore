import React from 'react';
import './Services.css';
import Service from './Service';

function Services(props) {
    return(
        <div>
      <div class="container-fluid py-4">
      	<div class="container mx-auto py-5 px-3">
      		<h2 class="text-center font-weight-bold mb-5"> Services</h2>
      		<div class="row">
			  <div class="col-4 text-center d-inline-block">      
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="fa fa-{props.Icon} text-warning align-middle"></span></h1>
                      fa fa-{props.Icon} text-warning align-middle
      			</div>
      			<h4 class="text-center font-weight-bold"> {props.Service}</h4>
      				<p class="mt-4">{props.Description} </p>
      			</div>
      			
				  <Service Icon={"undo"} Service={"Shipping"} Description={"velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt"} />
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="  fa fa-volume-control-phone text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Support</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="  fa fa-undo text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Return</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			</div>
      			<div class="row mt-3">
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="  fa fa-money text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Online Cash</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="  fa fa-exchange text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Exchange</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			<div class="col-4 text-center d-inline-block">
      				<div class="icon2 rounded rounded-circle mb-3 mx-auto">
      				<h1 class="m-0 display-4"><span class="  fa fa-thumbs-up text-warning align-middle"></span></h1>
      			</div>
      			<h4 class="text-center font-weight-bold"> Quality</h4>
      				<p class="mt-4">velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt</p>
      			</div>
      			</div>
      	</div>
      </div>
      </div>
    )
}
export default Services