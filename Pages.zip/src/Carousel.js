import React from 'react';
import './Carousel.css';
import b1 from './Images/b1.jpg';
import b2 from './Images/b2.jpg';
import b3 from './Images/b3.jpg';

function Carousel() {
    return (
      <div> 
          <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
         <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
         </ol>
         <div class="carousel-inner">
            <div class="carousel-item active">
               <img class="carousal-img-size" src={b1} alt="Los Angeles" /> 
               <div class="carousel-caption align-middle" >
                  <p class="slide-caption mb-2"> Pick The Best Toy For <br/>
                     Your Kid
                  </p>
                  <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Aenean commodo ligula eget dolorL orem ipsum dolor sit <br/> amet eget dolor </p>
                  <button class="btn mx-auto text-white btn-read-more">READ MORE </button>
               </div>
            </div>
            <div class="carousel-item">
               <img class="carousal-img-size" src={b2} alt="Chicago" /> 
               <div class="carousel-caption text-center">
                  <p class="slide-caption mb-2"> Sort Toys And Teddy bears <br/>
                     For Kids
                  </p>
                  <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Aenean commodo ligula eget dolorL orem ipsum dolor sit <br/> amet eget dolor </p>
                  <button class="btn slider-button text-white">READ MORE </button>
               </div>
            </div>
            <div class="carousel-item">
               <img class="carousal-img-size " src={b3} alt="New york" />
               <div class="carousel-caption text-center">
                  <p class="slide-caption mb-2"> Best Toys And Dolls <br/>
                     For Kids
                  </p>
                  <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Aenean commodo ligula eget dolorL orem ipsum dolor sit <br/> amet eget dolor </p>
                  <button class="btn slider-button text-white">READ MORE </button>
               </div>
            </div>
         </div>
         <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
         <span class="carousel-control-prev-icon" aria-hidden="true"></span>
         <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
         <span class="carousel-control-next-icon" aria-hidden="true"></span>
         <span class="sr-only">Next</span>
         </a>
      </div>





      </div>
    );
  }
  
  export default Carousel